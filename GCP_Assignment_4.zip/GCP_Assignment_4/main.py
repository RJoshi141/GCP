import sqlite3

from flask import Flask, request, g, render_template, send_file

DATABASE ='/tmp/chatbot.db'
app = Flask(__name__)
app.config.from_object(__name__)

def connect_to_database():
    return sqlite3.connect(app.config['DATABASE'])

def get_db():
    db = getattr(g, 'db', None)
    if db is None:
        db = g.db = connect_to_database()
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, 'db', None)
    if db is not None:
        db.close()

def execute_query(query, args=()):
    cur = get_db().execute(query, args)
    rows = cur.fetchall()
    cur.close()
    return rows

def commit():
    get_db().commit()

@app.route("/")
def hello():
    execute_query("DROP TABLE IF EXISTS userstable")
    execute_query("CREATE TABLE userstable (firstname text,lastname text,email text)")
    return render_template('index.html')

@app.route('/starteiquiry', methods =['POST', 'GET'])
def startinquiry():
    message = ''
    if request.method == 'POST' and str(request.form['ufname']) !="" and str(request.form['ulname']) != "" and str(request.form['mail']) != "":
        firstname = str(request.form['ufname'])
        lastname = str(request.form['ulname'])
        email = str(request.form['mail'])
        result = execute_query("""INSERT INTO userstable (firstname, lastname, email) values (?, ?, ?)""",(firstname, lastname, email))
        commit()
    elif request.method == 'POST':
        message = 'Please fill in all the required fields.'
    return render_template('Chat.html', message = message)

ChatWindowHTMLFirst = """
    <!DOCTYPE html>
    <html>
      <title>U of Cincy Inquiry Chatbot</title>
      <body>
      <div style="width:500px;margin: auto;border: 1px solid black;padding:10px">
        <form {{url_for('chatbotsystem')}} method="POST">
          <h1>UC College Inquiry Chabot</h1>
          <div class="icon">
    	 <i class="fas fa-user-circle"></i>
          </div>
          <div class="formcontainer">
          <div class="container">
           <label for="ufname"><strong>Hi! Welcome to the UC College Inquiry Portal</strong></label></br></br>
    	  <label for="ufname">Choose your questions from the list below:</strong></label></br></br>
    	  <label for="ufname">1. Does the college have a basket ball team?</label></br>
    	  <label for="ufname">2. Does it have Computer Science Major?</label></br>
    	  <label for="ufname">3. What is the in-state tuition?</label></br>
    	  <label for="ufname">4. Does it have an international office?</label></br>
    """

ChatWindowHTMLLast = """
    </br>
    </div>
    	<div class="text-box">
            <input type="text" style="width:300pt;height:50px" name="question" id="message" autocomplete="off" placeholder="Type your QUESTIONS here">
    	  <input class="send-button" style="width:50pt;height:50px" type="submit" value=">">
          </div></br>
           <a href='/endchat' align='center'">End Chat?</a>
    	</div>
        </form>
        </div>
      </body>
    </html>
    """

@app.route('/chatbotsystem', methods=['GET', 'POST'])
def chatbotsystem():
    global ChatWindowHTMLFirst
    ChatWindowHTMLMiddle = ''
    if request.method == 'POST' and str(request.form['question']).strip() != "":
        question_asked = str(request.form['question']).strip()
        response = ""
        if "basket ball team" in question_asked.lower():
            response = """
            </br><label for="ufname" style="color:blue;"><strong>""" + question_asked + """</strong></label></br>
            <label for="ufname"><strong>Yes! The team is known as the Cincinnati Bearcats.</strong></label></br>
            """
        elif "computer science major" in question_asked.lower():
            response = """
            </br><label for="ufname" style="color:blue;"><strong>""" + question_asked + """</strong></label></br>
            <label for="ufname"><strong>Yes! There is a Computer Science Major in the College of Engineering and Applied Sciences.</strong></label></br>
            """
        elif "in-state tuition" in question_asked.lower():
            response = """
            </br><label for="ufname" style="color:blue;"><strong>""" + question_asked + """</strong></label></br>
            <label for="ufname"><strong>The in-state tuition UC is $28,150.</strong></label></br>
            """
        elif "international office" in question_asked.lower():
            response = """
            </br><label for="ufname" style="color:blue;"><strong>""" + question_asked + """</strong></label></br>
            <label for="ufname"><strong>Yes! UC International Office is located at Edwards Center One, 47 W Corry St #7148, Cincinnati, OH 45221.</strong></label></br>
            """
        if response:
            ChatWindowHTMLMiddle = response
        else:
            ChatWindowHTMLMiddle = """
            </br><label for="ufname" style="color:blue;"><strong>""" + question_asked + """</strong></label></br>
            <label for="ufname"><strong>Sorry, the answer to your question doesn't exist. Please choose from the questions provided above.</strong></label></br>
            """

    ChatWindowHTMLFirst = ChatWindowHTMLFirst + ChatWindowHTMLMiddle
    return ChatWindowHTMLFirst + ChatWindowHTMLLast




EndChatHTMLFirst="""
<!DOCTYPE html>
<html>
  <title>Session Closed</title>
  <body>
  <div style="width:500px;margin: auto;border: 2px solid black;padding:10px">
    <form>
      <h1>Chat Session Closed</h1>
      <div class="icon">
	 <img src="https://static.thenounproject.com/png/878515-200.png" width="150" height="150"></img>
      </div>
      <div class="formcontainer">
      <div class="container">
        <label for="ufname"><strong>Hope your questions were answered.</strong></label></br></br>
"""

EndChatHTMLLast="""
 </div>
	</div>
    </form>
    </div>
  </body>
</html>
"""
@app.route("/endchat")
def endchat():
    global ChatWindowHTMLFirst
    ChatWindowHTMLFirst = """
        <!DOCTYPE html>
        <html>
          <title>U of Cincy Inquiry Chatbot</title>
          <body>
          <div style="width:500px;margin: auto;border: 1px solid black;padding:10px">
            <form {{url_for('chatbotsystem')}} method="POST">
              <h1>UC College Enquiry Chabot</h1>
              <div class="formcontainer">
              <div class="container">
               <label for="ufname"><strong>Hi! Welcome to the U of Cincy Inquiry Portal.</strong></label></br></br>
        	  <label for="ufname">Choose your questions from the list below:</label></br>
        	  <label for="ufname">1. Does the college have a basket ball team?</label></br></br>
        	  <label for="ufname">2. Does it have Computer Science Major?</label></br>
        	  <label for="ufname">3. What is the in-state tuition?</label></br>
        	  <label for="ufname"><4. Does it have an international office?</label></br>
        """
    result = execute_query("""SELECT firstname, lastname, email  FROM userstable""")
    if result:
        for row in result:
            Userdetails=row[0]+" "+row[1]+", "+row[2]
    EndChatHTMLMiddle="""
    User Information: <br>
    <label for="ufname"><strong>"""+Userdetails+"""</strong></label></br></br>
    Creator Information: <br>
    <label for="ufname"><strong>Ritika Joshi, joshirk@mail.uc.edu</strong></label></br></br>
    """
    return EndChatHTMLFirst+EndChatHTMLMiddle+EndChatHTMLLast

if __name__ == '__main__':
  app.run()
